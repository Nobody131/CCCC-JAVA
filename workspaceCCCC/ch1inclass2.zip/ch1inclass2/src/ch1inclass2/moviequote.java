// House 1/15 ch1 in class 2 
package ch1inclass2;

public class moviequote {

	public static void main(String[] args) {
	System.out.println("The Truman Show");	
	System.out.println("You never had a camera in my head.");
	System.out.println("Truman Burbank");
	System.out.println("Year 1998");
	}

}
