// House 1/15 ch1 assignment 1
public class triangle {

	public static void main(String[] args) {
		System.out.println("      T ");
		System.out.println("     TTT ");
		System.out.println("    TTTTT");
		System.out.println("   TTTTTTT");
		System.out.println("  TTTTTTTTT");
		System.out.println(" TTTTTTTTTTT");
		System.out.println("TTTTTTTTTTTTT");
	}

}
