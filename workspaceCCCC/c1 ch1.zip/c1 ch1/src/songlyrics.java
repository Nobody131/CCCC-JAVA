// House 1/15 in class 1 ch1  
public class songlyrics {

	public static void main(String[] args) {
		
System.out.println("Goodbye Weekend");
System.out.println("so long, Darling");
System.out.println("Mackys been a bad");
System.out.println("bad boy");
System.out.println("And when they're");
System.out.println("preaching, be sure to");
System.out.println("change me");

	}

}
